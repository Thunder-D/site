<?
if(isset($_POST['email'])&&$_POST['email']!=""){ //Проверка отправилось ли наше поля name и не пустые ли они
        $to = 'info@thunder-d.com'; //Почта получателя, через запятую можно указать сколько угодно адресов
        $subject = 'Новый вопрос'; //Загаловок сообщения
        $message = '
                <html>
                    <head>
                        <title>'.$subject.'</title>
                    </head>
                    <body>
                        <p>E-mail: '.$_POST['email'].'</p>
                    </body>
                </html>'; //Текст нащего сообщения можно использовать HTML теги
        $headers  = "Content-type: text/html; charset=utf-8 \r\n"; //Кодировка письма
        $headers .= "From: Отправитель <contact@thunder-d.com\r\n"; //Наименование и почта отправителя
        mail($to, $subject, $message, $headers); //Отправка письма с помощью функции mail
}
?>
